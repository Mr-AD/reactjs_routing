import React, { Component } from 'react';
import {
    BrowserRouter as Router,
    Route,
    Link,
    Redirect,
    withRouter
  } from "react-router-dom";

class Page1 extends Component {

   
   

  render() {

console.log("page 1")

    return (

      <div className="App">
<h1>This is Page1  Page ....  </h1>

      </div>
    );
  }
}

export default Page1;
