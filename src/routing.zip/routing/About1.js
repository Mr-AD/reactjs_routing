import React, { Component } from 'react';
import {
    BrowserRouter as Router,
    Route,
    Link,
    Redirect,
    withRouter
  } from "react-router-dom";

class About1 extends Component {

   
   

  render() {



    return (

      <div className="App">
<h1>This is About 1  Page ....  </h1>

      </div>
    );
  }
}

export default About1;
