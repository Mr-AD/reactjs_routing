import React, { Component } from 'react';
import {
    BrowserRouter as Router,
    Route,
    Link,
    Redirect,
    withRouter
  } from "react-router-dom";
import Home from './Home'
class About extends Component {

    constructor(props)
    {
        super(props)
        this.state = 
        {
            value:false
        }
    }
   

fun = () =>
{

    this.setState({value : !this.state.value})

    console.log("About Page1 === ",this.state.value)

}

  render() {

    if(this.state.value)
    {
        console.log("inside",this.state.value)
        return (
        <Router>
        <Redirect to=
        {{
            pathname :"/page1",
            // state : {from : this.props.location}
        }}

        />
        
        </Router>
        
        );
        // this.fun()


    }

    console.log("About Page === ",this.state.value)

    return (
        <Router>
      <div className="App">
<h1>This is About Page ....  </h1>

      <button onClick ={this.fun}> 2Redirect </button>

      </div>
      </Router>
    );
  }
}

export default About;
