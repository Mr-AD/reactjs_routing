

// import React from "react";
// import {
//   BrowserRouter as Router,
//   Route,
//   Link,
//   Redirect,
//   withRouter
// } from "react-router-dom";

// ////////////////////////////////////////////////////////////
// // 1. Click the public page
// // 2. Click the protected page
// // 3. Log in
// // 4. Click the back button, note the URL each time

// const AuthExample = () => (
//   <Router>
//     <div>
      
//       <ul>
//         <li>
//           <Link to="/public">Public Page</Link>
//         </li>
//         <li>
//           <Link to="/protected">Protected Page</Link>
//         </li>
//       </ul>
//       <Route path="/public" component={Public} />
//       <Route path="/login" component={Public} />
//       <PrivateRoute path="/protected" component={Protected} />
//     </div>
//   </Router>
// );


// const PrivateRoute = () => (
//   <Route
   
//     render={ () =>
//      (
//         <Redirect
//           to={{
//             pathname: "/login",
            
//           }}
//         />
//       )
//     }
//   />
// );

// const Public = () => <h3>Public</h3>;
// const Protected = () => <h3>Protected</h3>;



// export default AuthExample;



















import React, { Component } from 'react';

import { BrowserRouter as Router, Route,Redirect, Link } from "react-router-dom";

import Home from './Home';
 import About from './About';
 import About1 from './About1';
import Page1 from './Page1';
import Page2 from './Page2';



class App extends Component {

   

  render() {



    return (
      <div className="App">
<h1>This is Routing Test ....  </h1>

  <Router>
    <div>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/about">About</Link>
        </li>
        <li>
          <Link to="/about1">About1</Link>
        </li>
        <li>
          <Link to="/page1">Page1</Link>
        </li>
        <li>
          <Link to="/page2">Page2</Link>
        </li>
              </ul>

      <hr />

      <Route exact path="/" component={Home}  />
      <Route  exact path="/about" component={About} />
      <Route exact path="/about1" component={About1} />
      <Route exact path="/page1" component={Page1} />
      <Route exact path="/page2" component={Page2} />

    </div>

  </Router>


      </div>
    );
  }
}



export default App;
