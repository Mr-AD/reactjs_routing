import React, { Component } from 'react';
import {
    BrowserRouter as Router,
    Route,
    Link,
    Redirect,
    withRouter
  } from "react-router-dom";

class Page2 extends Component {

   
   

  render() {



    return (

      <div className="App">
<h1>This is Page2 1  Page ....  </h1>

      </div>
    );
  }
}

export default Page2;
